//
//  AnotherView.swift
//  friendsAndFriendsChat
//
//  Created by olivia Chen on 9/25/23.
//

import SwiftUI

struct AnotherView: View {
    var body: some View {
        Text("This is another view")
            .navigationBarTitle("Another View")
    }
}

struct AnotherView_Previews: PreviewProvider {
    static var previews: some View {
        AnotherView()
    }
}
