//
//  ChatRoomsMainPage.swift
//  friendsAndFriendsChat
//
//  Created by olivia Chen on 9/25/23.
//

import SwiftUI

struct ChatRoomsMainPage: View {
    @State private var searchText: String = ""
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    TextField("Search", text: $searchText)
                        .padding(7)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    Button(action: {
                        // Handle the search action
                    }) {
                        Image(systemName: "magnifyingglass")
                            .imageScale(.medium)
                            .foregroundColor(.black)
                    }
                    Button(action: {
                        // Handle the other button action
                        print(" Follow Me")
                    }) {
                        VStack {
                            Image(systemName: "heart.fill")
                                .imageScale(.large)
                            Text("Me")
                        }
                    }
                    
                }
                .padding(.horizontal)
                .padding(.top)
                differentEvents
                differentEvents
                differentEvents
                differentEvents
                differentEvents
                    
                Spacer()
                
            }
            .background(
                Image("Blob 1")
                    .offset(x:250, y:-100))
         
        }
        
    }
    var differentEvents:some View{
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .stroke(Color.black, lineWidth: 2)
                .frame(width: 350, height: 53)
            NavigationLink(destination: ChatRooms()){
                VStack(alignment:.leading) {
                    Text("Hotpot happy hours")
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                }
            }
        }
    }
}

struct ChatRoomsMainPage_Previews: PreviewProvider {
    static var previews: some View {
        ChatRoomsMainPage()
    }
}
