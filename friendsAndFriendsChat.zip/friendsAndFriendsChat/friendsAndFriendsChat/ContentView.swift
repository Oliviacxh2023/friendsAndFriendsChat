//
//  ContentView.swift
//  friendsAndFriendsChat
//
//  Created by olivia Chen on 9/23/23.
//

import SwiftUI

struct ContentView: View {
    @State private var searchText: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                // Search Bar
                HStack {
                    TextField("Search", text: $searchText)
                        .padding(7)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.leading) // 添加左侧填充
                    Button(action: {
                        // Handle the search action
                    }) {
                        Image(systemName: "magnifyingglass")
                            .imageScale(.medium)
                            .foregroundColor(.black)
                    }
                    Button(action: {
                        // Handle the other button action
                        print(" Follow Me")
                    }) {
                        VStack {
                            Image(systemName: "heart.fill")
                                .imageScale(.large)
                            Text("Follow Me")
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.top, -70)// 添加顶部填充
                
                // Rest of your content
                differentPeople
                differentPeople
                differentPeople
                Spacer()
            }
            .background(
                BlobView()
                    .offset(x: 200, y: 50)
                    .scaleEffect(2)
            )
            .navigationBarTitle("Home", displayMode: .inline) // 设置 displayMode 为 .inline
            .navigationBarHidden(true)
            
            
        }
    }
    
    var differentPeople: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .stroke(Color.black, lineWidth: 2)
                .frame(width: 350, height: 150)
            
            VStack(alignment: .leading) {
                HStack {
                    NavigationLink(destination: ChatRooms()) {
                        Text("Spicy Chengdu")
                            .foregroundColor(.black)
                            .fontWeight(.bold) 
                    }
                    Text("Sep 24")
                        .padding([.leading, .trailing], 50)
                }
                Text("Free Fried Chickens!")
                Text("Location: Spicy hotpot at BU")
            }
            .padding(.all, 15) // 添加整体填充
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
