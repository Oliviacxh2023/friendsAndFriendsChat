//
//  txt1.swift
//  friendsAndFriendsChat
//
//  Created by olivia Chen on 9/25/23.
//

import SwiftUI

struct txt1: View {
    var body: some View {
            NavigationView {
                VStack {
                    NavigationLink(destination: AnotherView()) {
                        Text("Click here to navigate")
                            .font(.title)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                .navigationBarTitle("Home")
            }
        }
}

struct txt1_Previews: PreviewProvider {
    static var previews: some View {
        txt1()
    }
}
