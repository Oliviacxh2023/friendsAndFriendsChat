//
//  friendsAndFriendsChatApp.swift
//  friendsAndFriendsChat
//
//  Created by olivia Chen on 9/23/23.
//

import SwiftUI

@main
struct friendsAndFriendsChatApp: App {
    var body: some Scene {
        WindowGroup {
           TabBar()
        }
    }
}
